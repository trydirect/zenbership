<div class="popupbody">

    <div class="pad24t">
        <p class="highlight">Some caller tags (example: %first_name%) may not be processed until the email is actually
            sent.</p>
    </div>
    <iframe width="100%" height="700" frameborder='0'
            src="cp-functions/get_temp.php?id=<?php echo $_POST['temp_id']; ?>"></iframe>
</div>